
Technical Assessment for the Senior DWH Developer position within Global Blue
-----------------------------------------------------------------------------

The assessment consists of 3 assignments, described in dedicated files:
- Adventure Assessment 1.txt
- Adventure Assessment 2.txt
- Adventure Assessment 3.txt


Also, i nthe ZIP file a a VS-Solution (version 2012) is attached, which is to be taken as a starting point for 

For solving / developing the solution, a Developer Edition of SQL Server / Visual Studio / SSMS can be used


IMPORTANT:

- Note that solving Assignment 2 is a MUST.
- From Assignment 1 and Assignment 3, only one must be solved, so choose freely which one of the two you want to solve.
- All textual responses / solutions per assignment are to be captured in the 3 TXT files (per assignment).


Sending your response back:
---------------------------

Please note that there is no time limitation for solving the solution.
Once [Assignment (1 or 3) and Assignment 2] are solved, please send back a ZIP file containing the adapted / extended VS solution and TXT files.


 We wish you good luck!
--------------------------


