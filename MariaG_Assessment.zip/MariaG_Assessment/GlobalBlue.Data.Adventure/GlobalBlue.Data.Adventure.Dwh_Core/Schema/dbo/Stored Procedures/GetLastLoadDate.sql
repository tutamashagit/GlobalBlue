﻿CREATE PROCEDURE [dbo].[GetLastLoadDate]
@TableName nvarchar(100)
AS
BEGIN
	IF NOT EXISTS(SELECT 1 FROM sys.tables WHERE name = @TableName AND Type = N'U')
	BEGIN
        PRINT N'The table does not exist in the data warehouse';
        THROW 55000, N'The table does not exist in the data warehouse', 1;
	END
	IF NOT EXISTS (SELECT 1 FROM [dbo].[LastLoadDate] WHERE TableName = @TableName)
		INSERT INTO [dbo].[LastLoadDate]
		SELECT @TableName, '1900-01-01'

	SELECT 
		[LastloadDate] AS [LastLoadDate]
    FROM [dbo].[LastLoadDate]
    WHERE 
		[TableName] = @TableName;
END;
