﻿CREATE PROCEDURE [dbo].[LoadDim_Employee]
	@LastLoadDate datetime
AS
BEGIN 
  SET NOCOUNT ON;

  DECLARE @LoadDateKey int 
  DECLARE @LoadDate datetime
  SELECT TOP(1) 
		@LoadDateKey = [DataLoadKey],
		@LoadDate = [StartDate]
  FROM dbo.DataLoad
  WHERE [TableName] = N'Dim_Employee'
    AND [FinishDate] IS NULL
  ORDER BY [DataLoadKey] DESC

  BEGIN TRANSACTION
  BEGIN TRY
	-- Insert blank records for late arriving departments
	-- records will be updated on the next Dim_Department load
	INSERT INTO [dbo].[Dim_Department]
		([DepartmentCode]
		,[Description]
		,[Name]
		,[ValidFrom]
		,[ValidTo]
		,[DataLoadKey])
	SELECT 
		DISTINCT e.[DepartmentId] as [DepartmentCode],
		'N/A' as [Description],
		'N/A' as [Name],
		CONVERT(datetime,'1900-01-01') AS [ValidFrom], -- Flag for the future update
		CONVERT(datetime, '9999-12-31') AS [ValidTo],
		@LoadDateKey
	FROM [Adventure_Legacy].[dbo].[Employee] e
	  LEFT JOIN [dbo].Dim_Department dd on e.DepartmentId = dd.DepartmentCode
	WHERE dd.DepartmentKey IS NULL
 
	-- Update ValidTo for records that were deleted in source
	UPDATE de
	SET de.[ValidTo] = @LoadDate,
		de.DataLoadKey = @LoadDateKey
	FROM 
		[dbo].[Dim_Employee] de
		LEFT JOIN [Adventure_Legacy].[dbo].[Employee] e ON de.EmployeeCode = e.Id
	WHERE de.[ValidTo] = CONVERT(datetime, '9999-12-31') 
	  AND e.Id IS NULL

    -- Update ValidTo for records that were updated in source
    UPDATE de
    SET de.[ValidTo] = e.ModifiedDateTime,
		de.DataLoadKey = @LoadDateKey
    FROM [dbo].[Dim_Employee] de 
	  INNER JOIN [Adventure_Legacy].[dbo].[Employee] e ON de.EmployeeCode = e.Id 
    WHERE de.[ValidTo] = CONVERT(datetime, '9999-12-31')  
	  AND e.[ModifiedDateTime] > @LastLoadDate 
  
    -- Insert updated and new source records 
	INSERT INTO [dbo].[Dim_Employee] (
			[EmployeeCode],	
			[DepartmentKey],	
			[FirstName],
			[LastName],
			[ContractStarted],
			[ContractTerminated],
			[ValidFrom],
			[ValidTo],
			[DataLoadKey])
	SELECT 
			e.[Id] as [EmployeeCode],	
			dd.[DepartmentKey],	
			e.[FirstName],
			e.[LastName],
			e.[ContractStarted],
			e.[ContractTerminated],
		   [ModifiedDateTime] AS [ValidFrom],
		   CONVERT(datetime, '9999-12-31') AS [ValidTo],
		   @LoadDateKey
	FROM [Adventure_Legacy].[dbo].Employee e
      INNER JOIN [dbo].Dim_Department dd on e.DepartmentId = dd.DepartmentCode and dd.ValidTo ='9999-12-31'
	WHERE e.[ModifiedDateTime] > @LastLoadDate
  
	-- Mark data load as completed successfully  
	UPDATE [dbo].DataLoad
	   SET FinishDate = SYSDATETIME(),
           Status = 'S'
    WHERE DataLoadKey = @LoadDateKey;

	UPDATE [dbo].[LastLoadDate]
       SET [LastLoadDate] = SYSDATETIME()
    WHERE [TableName] = N'Dim_Employee';
	COMMIT

END TRY
BEGIN CATCH
	IF(@@TRANCOUNT > 0)
        ROLLBACK TRAN;

	-- Mark data load with Error status  
	UPDATE [dbo].DataLoad
	  SET Status = 'E'
	WHERE DataLoadKey = @LoadDateKey;
	THROW
END CATCH

END;
