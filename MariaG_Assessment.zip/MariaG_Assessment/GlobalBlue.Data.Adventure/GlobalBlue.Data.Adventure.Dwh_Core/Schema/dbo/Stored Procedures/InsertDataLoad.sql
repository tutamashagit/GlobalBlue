﻿CREATE PROCEDURE [dbo].[InsertDataLoad]
	@TableName nvarchar(100)
AS
BEGIN

/* 
Insert record into DataLoad table as the first step of table load.
 Status values:
- P = In progress
- E = Error
- S = Success
*/
  INSERT INTO [dbo].[DataLoad](
	 [TableName]
	,[StartDate]
	,[FinishDate]
	,[Status]
	)
  VALUES (
	 @TableName
	,SYSDATETIME()
	,NULL
	,'P'
	);
END;
