﻿
CREATE PROCEDURE [dbo].[LoadDim_Department]
	@LastLoadDate datetime
AS
BEGIN 
   SET NOCOUNT ON;

   DECLARE @LoadDateKey int 
   DECLARE @LoadDate datetime
   SELECT TOP(1) 
		@LoadDateKey = [DataLoadKey],
		@LoadDate = [StartDate]
    FROM dbo.DataLoad
    WHERE [TableName] = N'Dim_Department'
      AND [FinishDate] IS NULL
    ORDER BY [DataLoadKey] DESC
  
  BEGIN TRANSACTION
  BEGIN TRY
  --Update ValidTo for deleted records in Source
	UPDATE dd
	  SET dd.[ValidTo] = @LoadDate,
	      dd.DataLoadKey = @LoadDateKey
	FROM [dbo].[Dim_Department] dd 
	  LEFT JOIN [Adventure_Legacy].[dbo].[Departments] d ON dd.DepartmentCode = d.Id
	WHERE d.Id IS NULL 
	  AND dd.[ValidTo] = '9999-12-31'
	  AND dd.[ValidFrom] <> CONVERT(datetime, '1900-01-01') 
	   
	--Update ValidTo for records that were updated in source
	UPDATE dd
	  SET 
		dd.[ValidTo] = d.ModifiedDateTime,
		dd.DataLoadKey = @LoadDateKey
	FROM [dbo].[Dim_Department] dd 
	  INNER JOIN [Adventure_Legacy].[dbo].[Departments] d ON dd.DepartmentCode = d.Id
	WHERE dd.[ValidTo] = CONVERT(datetime, '9999-12-31') 
	  AND d.[ModifiedDateTime] > @LastLoadDate 
	  AND dd.[ValidFrom] <> CONVERT(datetime, '1900-01-01') 

	  -- Update late arriving dimention
	UPDATE dd
	SET 
		dd.[Description] = d.[Description],
		dd.[Name] = d.[Name],
		dd.[ValidFrom] = d.[ModifiedDateTime],
		dd.[ValidTo] = '9999-12-31',
		dd.DataLoadKey = @LoadDateKey
	FROM [dbo].[Dim_Department] dd 
	  INNER JOIN [Adventure_Legacy].[dbo].[Departments] d ON dd.DepartmentCode = d.Id
	WHERE dd.[ValidFrom] = '1900-01-01' 
  
	-- Insert updated and new source records 
	INSERT INTO [dbo].[Dim_Department]
			([DepartmentCode],
			[Description],
			[Name],
			[ValidFrom],
			[ValidTo],
			[DataLoadKey])
	SELECT 
			d.[Id] as [DepartmentCode],
			d.[Description],
			d.[Name],
			[ModifiedDateTime] AS [ValidFrom],
			CONVERT(datetime, '9999-12-31') AS [ValidTo],
			@LoadDateKey
	FROM [Adventure_Legacy].[dbo].[Departments] d
	WHERE d.[ModifiedDateTime] > @LastLoadDate
	   AND d.[Id] NOT IN 
	   (
	   SELECT dd.[DepartmentCode] 
	   FROM [dbo].Dim_Department dd 
	   WHERE dd.ValidTo = CONVERT(datetime, '9999-12-31')
	   )
  	
	-- Mark data load as completed successfully  
	UPDATE [dbo].DataLoad
		SET FinishDate = SYSDATETIME(),
			Status = 'S'
	WHERE DataLoadKey = @LoadDateKey;
	 
	UPDATE [dbo].[LastLoadDate]
		SET [LastLoadDate] = SYSDATETIME()
	WHERE [TableName] = N'Dim_Department';
	COMMIT;
	
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT > 0)
		ROLLBACK
		
	-- Mark data load with Error status  
	UPDATE [dbo].DataLoad
	  SET Status = 'E'
	WHERE DataLoadKey = @LoadDateKey;
	THROW
END CATCH

END;
