﻿CREATE TABLE [dbo].[DataLoad]
(
	[DataLoadKey]	[int] IDENTITY(1,1) NOT NULL,
	[TableName]		[nvarchar](200) NOT NULL,
	[StartDate]		[datetime]	NOT NULL,
	[FinishDate]	[datetime]	NULL,
	[Status]		[nvarchar](1) NOT NULL CONSTRAINT [DF_DataLoad_Status] DEFAULT (N'P'),
 CONSTRAINT [PK_DataLoad] PRIMARY KEY CLUSTERED ([DataLoadKey] ASC)
)

