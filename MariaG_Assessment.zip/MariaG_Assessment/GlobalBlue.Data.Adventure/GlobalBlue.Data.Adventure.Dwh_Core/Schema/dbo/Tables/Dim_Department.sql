﻿CREATE TABLE [dbo].[Dim_Department]
 (  [DepartmentKey] [smallint]	NOT NULL IDENTITY(1, 1),
	[DepartmentCode] [smallint]	NOT NULL,
	[Description] [varchar](64) NOT NULL,
	[Name] [varchar](32) NOT NULL,
	[ValidFrom] [datetime]	NOT NULL,
	[ValidTo] [datetime]	NULL,
	[DataLoadKey] [int] NOT NULL
	CONSTRAINT PK_Dim_Department PRIMARY KEY CLUSTERED ([DepartmentKey])
);