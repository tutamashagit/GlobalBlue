﻿CREATE TABLE [dbo].[Dim_Employee]
(	[EmployeeKey]	[int] NOT NULL IDENTITY (1, 1),
	[EmployeeCode]	[int] NOT NULL,
	[DepartmentKey]	[smallint] NOT NULL,
	[FirstName]		[varchar](32) NOT NULL,
	[LastName]		[varchar](32) NOT NULL,
	[ContractStarted] [date] NOT NULL,
	[ContractTerminated] [date] NULL,
	[ValidFrom]		[datetime]	NOT NULL,
	[ValidTo]		[datetime] NULL,
	[DataLoadKey]	[int] NOT NULL
	CONSTRAINT PK_Dim_Employee PRIMARY KEY CLUSTERED ([EmployeeKey])
)