﻿CREATE TABLE [dbo].[LastLoadDate](
	[LastLoadDateKey] [int] IDENTITY (1,1) NOT NULL,
	[TableName]		[nvarchar](100) NOT NULL,
	[LastLoadDate]		[datetime]  NULL,
 CONSTRAINT [PK_LoadDates] PRIMARY KEY CLUSTERED 
([LastLoadDateKey] ASC)
)
