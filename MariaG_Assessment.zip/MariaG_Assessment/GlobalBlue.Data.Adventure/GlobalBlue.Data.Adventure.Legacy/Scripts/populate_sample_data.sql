﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


TRUNCATE TABLE [dbo].[Departments];
INSERT INTO [dbo].[Departments]
([Description], [Name],[CreatedDateTime],[ModifiedDateTime])
VALUES 
	('Creative department', 'Creative', '1999-02-02', '2005-12-25'),
	('Editorial department','Editorial', '1999-02-02', '1999-12-12'),
	('Mailroom department', 'Mailroom', '2002-02-02', '2005-12-08'),
	('Import Export department', 'Import Export', '2001-10-04', '2008-10-01'),
	('Accounting department', 'Accounting', '1998-01-12', '2015-12-08')

TRUNCATE TABLE [dbo].[Employee] ;
INSERT INTO [dbo].[Employee] 
([DepartmentId], [FirstName], [LastName], [ContractStarted],[CreatedDateTime],[ModifiedDateTime])
VALUES 
(1, 'Jerry', 'Seinfeld', '1989-05-07','1989-05-07', Dateadd (dd, -7, getdate())),
(2, 'Elaine', 'Benes', '1989-05-07', '1989-05-07', Dateadd (dd, -7, getdate())),
(3, 'Cosmo', 'Kramer', '1989-05-07','1989-05-07', Dateadd (dd, -7, getdate())),
(4, 'George', 'Costanza','1989-05-07', '1989-05-07', Dateadd (dd, -7, getdate())),
(3, 'Postman', 'Newman', '1992-08-09','1992-08-09', Dateadd (dd, -7, getdate())),
(4, 'Frank', 'Costanza', '1993-02-09','1993-02-09', Dateadd (dd, -7, getdate())),
(4, 'Estelle', 'Costanza', '1993-02-09','1993-02-09', Dateadd (dd, -7, getdate())),
(4, 'Leo', 'Uncle', '1991-08-01', '1991-08-01', Dateadd (dd, -7, getdate())),
(1, 'Larry', 'David', '1989-05-07','1989-05-07', Dateadd (dd, -7, getdate())),
(5, 'Helen', 'Seinfeld', '1990-08-09','1990-08-09', Dateadd (dd, -7, getdate())),
(5, 'Morty', 'Seinfeld', '1990-08-09','1990-08-09', Dateadd (dd, -7, getdate()));
