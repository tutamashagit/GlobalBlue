﻿CREATE TABLE [dbo].[CustomerPropertyMapping]
(
		[CustomerID]			INT			NOT NULL
	,	[CustomerPropertyID]	INT			NOT NULL
	
	,	[CreatedDateTime]		DATETIME2	NOT NULL CONSTRAINT DF_CustomerPropertiesMapping_CreatedDateTime DEFAULT SYSUTCDATETIME()
	,	[ModifiedDateTime]		DATETIME2	NOT NULL CONSTRAINT DF_CustomerPropertiesMapping_ModifiedDateTime DEFAULT SYSUTCDATETIME()

	,	CONSTRAINT PK_dboCustomerPropertyMapping
			PRIMARY KEY CLUSTERED (
					[CustomerID]
				,	[CustomerPropertyID]
			)
);
GO
