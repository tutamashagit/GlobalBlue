﻿CREATE TABLE [dbo].[Employee]
(
	[Id]					INT			NOT NULL IDENTITY(1, 1)
,	[DepartmentId]			SMALLINT	NOT NULL
,	[FirstName]				VARCHAR(32) NOT NULL
,	[LastName]				VARCHAR(32) NOT NULL
,	[ContractStarted]		DATE		NOT NULL
,	[ContractTerminated]	DATE		NULL
,	[CreatedDateTime]		DATETIME2	NOT NULL CONSTRAINT DF_Employee_CreatedDateTime DEFAULT SYSUTCDATETIME()
,	[ModifiedDateTime]		DATETIME2	NOT NULL CONSTRAINT DF_Employee_ModifiedDateTime DEFAULT SYSUTCDATETIME()
,	CONSTRAINT PK_Employee PRIMARY KEY CLUSTERED ([Id])
);
