﻿CREATE TABLE [dbo].[CustomerProperties]
(
		[CustomerPropertyID]	INT				NOT NULL	IDENTITY(1,1)
	,	[CustomerPropertyName]	NVARCHAR(64)	NOT NULL
	,	[CustomerPropertyValue]	NVARCHAR(128)	NOT NULL

	,	[CreatedDateTime]		DATETIME2		NOT NULL CONSTRAINT DF_CustomerProperties_CreatedDateTime DEFAULT SYSUTCDATETIME()
	,	[ModifiedDateTime]		DATETIME2		NOT NULL CONSTRAINT DF_CustomerProperties_ModifiedDateTime DEFAULT SYSUTCDATETIME()

	,	CONSTRAINT [PK_dboCustomerProperties]
			PRIMARY KEY CLUSTERED (
					[CustomerPropertyID]
			)

	,	CONSTRAINT [UQ_dboCustomerProperties_CustomerPropertyName_CustomerPropertyValue]
			UNIQUE NONCLUSTERED (
					[CustomerPropertyName]
				,	[CustomerPropertyValue]
			)
);
GO
