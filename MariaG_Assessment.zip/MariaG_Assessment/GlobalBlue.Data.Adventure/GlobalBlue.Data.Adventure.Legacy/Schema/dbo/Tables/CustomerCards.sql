﻿CREATE TABLE [dbo].[CustomerCards]
(
	[Id]					INT			NOT NULL IDENTITY(1, 1)
,	[CustomerId]			INT			NOT NULL
,	[CardToken]				VARCHAR(32) NOT NULL
,	[IssuingCountryIsoCode] SMALLINT	NOT NULL
,	[CreatedDateTime]		DATETIME2	NOT NULL CONSTRAINT DF_CustomerCard_CreatedDateTime DEFAULT SYSUTCDATETIME()
,	[ModifiedDateTime]		DATETIME2	NOT NULL CONSTRAINT DF_CustomerCard_ModifiedDateTime DEFAULT SYSUTCDATETIME()
,	CONSTRAINT PK_CustomerCard PRIMARY KEY CLUSTERED ([Id])
);
