﻿CREATE TABLE [dbo].[Transactions]
(
	[Id]				INT				NOT NULL IDENTITY(1000000, 1)
,	[CustomerId]		INT				NOT NULL
,	[CreatedDateTime]	DATETIME2		NOT NULL
,	[TransactionAmount] DECIMAL(36, 6)	NOT NULL
);
