﻿CREATE PROCEDURE [dbo].[GetTransactions]
	@CustomerCardIssuingCountry SMALLINT
,	@AsAtDateTime				DATE = '1899-01-01'
,	@CustomerName				VARCHAR(64) = ''
AS
BEGIN;
	WITH TransactionIds
	AS
	(
		SELECT
			[Id]	AS [TransactionId]
		FROM
			[dbo].[Transactions]
		WHERE
			DATEADD(DAY, DATEDIFF(DAY, 0, [CreatedDateTime]), 0) = @AsAtDateTime
			OR @AsAtDateTime = '1899-01-01'
	)
	,CustomerIds
	AS
	(
		SELECT
			[Id]	AS [CustomerId]
		FROM
			[dbo].[Customers]
		WHERE
			(
				CONCAT([FirstName], ' ', [LastName]) = @CustomerName
				OR @CustomerName = ''
			)
			AND [Id] IN
				(
					SELECT
						T.[CustomerId]
					FROM
						[dbo].[Transactions]		T
						INNER JOIN TransactionIds TID
							ON TID.[TransactionId] = T.[Id]
					GROUP BY
						T.[CustomerId]
				)
	)
	,TransactionDetails
	AS
	(
		SELECT
			*
		FROM
			[dbo].[Transactions]
		WHERE
			[Id] IN
			(
				SELECT
					[TransactionId]
				FROM
					TransactionIds
			)
	)
	,CustomerDetails
	AS
	(
		SELECT
			*
		FROM
			[dbo].[Customers]
		WHERE
			[Id] IN
			(
				SELECT
					[CustomerId]
				FROM
					CustomerIds
			)
	)

	SELECT
		CONCAT	(CD.[FirstName], ' ', CD.[LastName])	AS [CustomerFullName]
	,	MAX(CC.[CardToken])								AS [CardToken]
	,	SUM(TD.[TransactionAmount])						AS [TransactionAmount]
	FROM
		TransactionDetails				TD
		INNER JOIN CustomerDetails		CD
			ON CD.[Id] = TD.[CustomerId]
		LEFT JOIN [dbo].[CustomerCards] CC
			ON CC.[CustomerId] = [CD].Id
	WHERE
		CC.[IssuingCountryIsoCode] = @CustomerCardIssuingCountry
	GROUP BY
		CONCAT(CD.[FirstName], ' ', CD.[LastName]);
END;
