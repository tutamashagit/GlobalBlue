﻿CREATE PROCEDURE [dbo].[GetTransactions_Revised]
   @CustomerCardIssuingCountry  SMALLINT
,  @AsAtDateTime        DATE        = NULL
,  @CustomerName        VARCHAR(65) = NULL      
AS
BEGIN
  
  ;WITH TransactionDetails AS
  ( SELECT [Id], [TransactionAmount], [CustomerId]
    FROM   [dbo].[Transactions] T
    WHERE  DateDiff(DAY, [CreatedDateTime], @AsAtDateTime) = 0 OR @AsAtDateTime IS NULL
  )
  , CustomerDetails AS
  (
    SELECT   Cust.[Id]
         , Cust.[CustomerFullName]
    FROM ( 
        SELECT [Id],
        CONCAT([FirstName], ' ', [LastName]) AS [CustomerFullName]
        FROM [dbo].[Customers]
        WHERE EXISTS ( SELECT 1   
               FROM [dbo].[Transactions] T          
               WHERE EXISTS (SELECT 1 FROM TransactionDetails WHERE [Id] = T.[Id])
               AND T.[CustomerId] = [Customers].[Id]
            )
       ) AS Cust
    WHERE  Cust.[CustomerFullName] = @CustomerName OR @CustomerName IS NULL
  )

  SELECT MAX(CD.[CustomerFullName])  AS [CustomerFullName]  
       , MAX(CC.[CardToken])         AS [CardToken]
       , SUM(TD.[TransactionAmount]) AS [TransactionAmount]
  FROM
    TransactionDetails               TD
    INNER JOIN CustomerDetails       CD  ON CD.[Id] = TD.[CustomerId]
    INNER JOIN [dbo].[CustomerCards] CC  ON CC.[CustomerId] = CD.[Id]
  WHERE CC.[IssuingCountryIsoCode] = @CustomerCardIssuingCountry or @CustomerCardIssuingCountry IS NULL
  GROUP BY CD.[Id];
END;